﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include <aws/textract/TextractEndpointProvider.h>

namespace Aws
{
namespace Textract
{
namespace Endpoint
{
} // namespace Endpoint
} // namespace Textract
} // namespace Aws
